<?php
ob_start();
include '../core/database.php';

if (!($user -> LoggedIn()))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
if (!($user -> isAdmin($odb)))
{
	die('You are not admin');
}
if (!($user -> notBanned($odb)))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
$page = "Dashboard";
include ("head.php");
$id = $_GET['id'];
$SQLGetInfo = $odb -> prepare("SELECT * FROM `users` WHERE `ID` = :id LIMIT 1");
$SQLGetInfo -> execute(array(':id' => $_GET['id']));
$userInfo = $SQLGetInfo -> fetch(PDO::FETCH_ASSOC);
$username = $userInfo['username'];
$password = $userInfo['password'];
$email = $userInfo['email'];
$rank = $userInfo['rank'];
$membership = $userInfo['membership'];
$status = $userInfo['status'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pika - Admin</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
</head>

<body>
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

            <!-- Navbar End -->
			<?php 
				   if (isset($_POST['rBtn']))
				   {
					$sql = $odb -> prepare("DELETE FROM `users` WHERE `ID` = :id");
					$sql -> execute(array(':id' => $id));
					header('location: ca.php');
				   }
				   if (isset($_POST['updateBtn']))
				   {
					$update = false;
					if ($username!= $_POST['username'])
					{
						if (ctype_alnum($_POST['username']) && strlen($_POST['username']) >= 4 && strlen($_POST['username']) <= 15)
						{
							$SQL = $odb -> prepare("UPDATE `users` SET `username` = :username WHERE `ID` = :id");
							$SQL -> execute(array(':username' => $_POST['username'], ':id' => $id));
							$update = true;
							$username = $_POST['username'];
						}
						else
						{
							echo '<div class="g_12"><div class="alert alert-danger"><strong>Error</strong>: Username has to be 4-15 characters and alphanumeric</div></div>';
						}
					}
					if (!empty($_POST['password']))
					{
						$SQL = $odb -> prepare("UPDATE `users` SET `password` = :password WHERE `ID` = :id");
						$SQL -> execute(array(':password' => SHA1($_POST['password']), ':id' => $id));
						$update = true;
						$password = SHA1($_POST['password']);
					}
					if ($email != $_POST['email'])
					{
						if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
						{
							$SQL = $odb -> prepare("UPDATE `users` SET `email` = :email WHERE `ID` = :id");
							$SQL -> execute(array(':email' => $_POST['email'], ':id' => $id));
							$update = true;
							$email = $_POST['email'];
						}
						else
						{
							echo '<div class="g_12"><div class="alert alert-danger"><strong>Error</strong>: Email is invalid</div></div>';
						}
					}
					if ($rank != $_POST['rank'])
					{
						$SQL = $odb -> prepare("UPDATE `users` SET `rank` = :rank WHERE `ID` = :id");
						$SQL -> execute(array(':rank' => $_POST['rank'], ':id' => $id));
						$update = true;
						$rank = $_POST['rank'];
					}
					if ($membership != $_POST['plan'])
					{
						if ($_POST['plan'] == 0)
						{
							$SQL = $odb -> prepare("UPDATE `users` SET `expire` = '0', `membership` = '0' WHERE `ID` = :id");
							$SQL -> execute(array(':id' => $id));
							$update = true;
							$membership = $_POST['plan'];
						}
						else
						{
							$getPlanInfo = $odb -> prepare("SELECT `unit`,`length` FROM `plans` WHERE `ID` = :plan");
							$getPlanInfo -> execute(array(':plan' => $_POST['plan']));
							$plan = $getPlanInfo -> fetch(PDO::FETCH_ASSOC);
							$unit = $plan['unit'];
							$length = $plan['length'];
							$newExpire = strtotime("+{$length} {$unit}");
							$updateSQL = $odb -> prepare("UPDATE `users` SET `expire` = :expire, `membership` = :plan WHERE `id` = :id");
							$updateSQL -> execute(array(':expire' => $newExpire, ':plan' => $_POST['plan'], ':id' => $id));
							$update = true;
							$membership = $_POST['plan'];
						}
					}
					
					if ($status != $_POST['status'])
					{
						$SQL = $odb -> prepare("UPDATE `users` SET `status` = :status WHERE `ID` = :id");
						$SQL -> execute(array(':status' => $_POST['status'], ':id' => $id));
						$update = true;
						$status = $_POST['status'];
					}
					if ($update == true)
					{
						echo '<div class="pt-4 px-4 col-xl-6"><div class="alert alert-success"><strong>Success</strong>: User has been updated</div></div>';
					}
					else
					{
						echo '<div class="pt-4 px-4 col-xl-6"><div class="alert alert-danger"><strong>Error</strong>: Nothing was updated</div></div>';
					}
					}
					//edituser
				   ?>
            <!-- Blank Start -->
			<form action="" method="POST" class="form-horizontal">
			<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
			<div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Edit User</h6>
							<div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Username</label>
									<input class="form-control form-control-sm" name="username" maxlength="15" value="<?php echo $username;?>" type="text"/>
                                    <div id="emailHelp" class="form-text">Username
                                    </div>
                                </div>
								<div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email</label>
                                    <input class="form-control form-control-sm" name="email" type="text" value="<?php echo htmlentities($email);?>"/>
                                    <div id="emailHelp" class="form-text">Example@Gmail.com
                                    </div>
                                </div>
								<div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Password</label>
									<input class="form-control form-control-sm" name="password" placeholder="Password" type="password"/>
                                    <div id="emailHelp" class="form-text">********
                                    </div>
                                </div>
							<select class="form-select form-select-sm mb-3" name="status">
								<?php
								function selectedS($check, $rank)
								{
									if ($check == $rank)
									{
										return 'selected="selected"';
									}
								}
								?>
                                <option value="0" <?php echo selectedS(0, $status); ?>>Active</option>
                                <option value="1" <?php echo selectedS(1, $status); ?>>Banned</option>
								</select>
							<select class="form-select form-select-sm mb-3" name="plan">
								<option value="0">No Membership</option>
								<?php 
									$SQLGetMembership = $odb -> query("SELECT * FROM `plans` ORDER BY `price` ASC");
									while($memberships = $SQLGetMembership -> fetch(PDO::FETCH_ASSOC))
									{
										$mi = $memberships['ID'];
										$mn = $memberships['name'];
										$selectedM = ($mi == $membership) ? 'selected="selected"' : '';
										echo '<option value="'.$mi.'" '.$selectedM.'>'.$mn.'</option>';
									}
								?>
								</select>
							<select class="form-select form-select-sm mb-3" name="rank">
								<?php
								function selectedR($check, $rank)
								{
									if ($check == $rank)
									{
										return 'selected="selected"';
									}
								}
								?>
                                <option value="0" <?php echo selectedR(0, $rank); ?> >User</option>
                                <option value="1" <?php echo selectedR(1, $rank); ?> >Admin</option>
								</select>
						<div class="panel-footer">
							<button type="submit" name="updateBtn" class="btn btn-sm btn-success"><i class="fa fa-flash"></i> Update</button>
							<button type="submit" name="rBtn" class="btn btn-sm btn-danger"><i class="fa fa-ban"></i> Remove User</button>
						</div>	
                    </div>
                 </div>
					
			</form>
			<?php
			// settings/api
				if (isset($_POST['changeBtn']))
		                {
                		        $bootername = $_POST['bootername'];
								$booterlogo = $_POST['booterlogo'];
								$wmsg = $_POST['wmsg'];
								$booterurl = $_POST['booterurl'];
                        		$errors = array();
                        		if (empty($bootername) || empty($booterlogo) || empty ($wmsg))
                        		{
                        		        $errors[] = 'Please verify all fields';
                        		}
                        		if (empty($errors))
                        		{
                        		        $SQLinsert = $odb -> prepare("UPDATE `admin` SET `bootername` = :newbootername, `booterurl` = :url, `booterlogo` = :newbooterlogo, `wmsg` = :newwmsg WHERE `id` = 1");
                        		        $SQLinsert -> execute(array(":newbootername" => $bootername, ":url" => $booterurl, ":newbooterlogo" => $booterlogo, ":newwmsg" => $wmsg));
                        		        echo '<div class="mb-4 col-xl-6"> <div class="alert alert-success"><strong>Success</strong>: site configurations have been updated</div>';
                        		}
                        		else
                        		{
                        		        echo '<div class="col-sm-12 col-xl-6"> <div class="alert alert-danger"><strong>Error</strong>: please fill in required information!</div>';
                        		}
                		}
				?>
			<div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Settings</h6>
							<form action="" method="POST" class="form-horizontal">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Website Name</label>
									<input class="form-control" name="bootername" value="<?php echo $odb->query("SELECT `bootername` FROM `admin` LIMIT 1")->fetchColumn(0); ?>" type="text">
                                    <div id="emailHelp" class="form-text">Dislpay with $SiteName
                                    </div>
                                </div>
								<div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">URL</label>
									<input class="form-control" name="booterurl" value="<?php echo $odb->query("SELECT `booterurl` FROM `admin` LIMIT 1")->fetchColumn(0); ?>" type="text">
                                    <div id="emailHelp" class="form-text">Used in tags
                                    </div>
                                </div>
								<div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Welcome Message</label>
									<input class="form-control" name="wmsg" value="<?php echo $odb->query("SELECT `wmsg` FROM `admin` LIMIT 1")->fetchColumn(0); ?>" type="text">
                                    <div id="emailHelp" class="form-text">Sends a message to a user when they first make an account.
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label ">Logo</label>
                                    <input class="form-control" name="booterlogo" value="<?php echo $odb->query("SELECT `booterlogo` FROM `admin` LIMIT 1")->fetchColumn(0); ?>" type="text">
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Testt</label>
                                </div>
								<div class="panel-footer">
							<button type="submit" name="changeBtn" class="btn btn-sm btn-success"><i class="fa fa-flash"></i> Change</button>
						</div>	
                            </form>
                        </div>
                    </div>
                    <div class="bg-secondary rounded h-100 p-4">
                    <?php 
				if (isset($_POST['addBtn']))
				{
					$detailAdd = $_POST['detailAdd'];
					if (!empty($detailAdd))
					{
						$SQLinsert = $odb -> prepare("INSERT INTO `news` VALUES(NULL, :uid, :detail, UNIX_TIMESTAMP())");
						$SQLinsert -> execute(array(':detail' => $detailAdd, ":uid" => $_SESSION['ID']));
						echo '<div class="g_12"><div class="alert alert-success"><strong>Success</strong>:You have added your news to the Dashboard! </div></div>';
					}
					else
					{
						echo '<div class="g_12"><div class="alert alert-danger"><strong>Error</strong>:Please fill in all fields</div></div>';
					}
				}
				?>
                            <h6 class="mb-4">Basic Form</h6>
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                                    <input type="text" class="form-control" name="detailAdd" placeholder="Provide as much information to Pika Clients about what going on!">
                                    </div>
                                    <div class="panel-footer">
							<div class="btn-group">
								<button type="button" class="btn btn-link"><i class="fa fa-news"></i></button>
							</div>
							
							<div class="pull-right">
								<button type="submit" name="addBtn" class="btn btn-success">submit</button>
							</div>	
							</form>
						</div>
                            </form>
                        </div>
</body>
            <!-- Blank End -->


            <!-- Footer Start -->
            <?php
				$getNames = $odb -> query("SELECT * FROM `admin`");
				while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
					$SiteName = $Names['bootername'];
				}
			?>
            
<div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"><?php echo $SiteName ?></a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            Designed By <a href="#">FileGone</a>
                            <br>Distributed By: <a href="#" target="_blank"><?php echo $SiteName ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

	    <!-- JavaScript Libraries -->
		<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/chart/chart.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../lib/tempusdominus/js/moment.min.js"></script>
    <script src="../lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../js/main.js"></script>
</body>

</html>