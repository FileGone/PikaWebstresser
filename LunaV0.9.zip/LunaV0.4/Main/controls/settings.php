<?php


ob_start();
include '../core/database.php';

if (!($user -> LoggedIn()))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
if (!($user -> isAdmin($odb)))
{
	die('You are not admin');
}
if (!($user -> notBanned($odb)))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
$page = "Site Settings";
include ("head.php");
				?>
<body>	
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
			<div class="container-fluid pt-4 px-4">
			<?php
							if (isset($_POST['methodAdd']))
							{
								$friendlyAdd = $_POST['friendly'];
								$nameAdd = $_POST['name'];
								if (empty($nameAdd) || empty($friendlyAdd))
								{
									echo '<div class="alert alert-danger"><strong>Error</strong>: please fill in all the field that are required!</div>';
								}
								else
								{
									$SQLinsert = $odb -> prepare("INSERT INTO `methods` VALUES(NULL, :friendly, :name)");
									$SQLinsert -> execute(array(':friendly' => $friendlyAdd, ':name' => $nameAdd));
									echo '<div class="g_12"><div class="alert alert-success"><strong>Success</strong>: your method has been added!</div>';
								}
							}
							if (isset($_POST['deleteBtn']))
								{
									$deletes = $_POST['deleteCheck'];
									foreach($deletes as $delete)
									{
										$SQL = $odb -> prepare("DELETE FROM `methods` WHERE `ID` = :id LIMIT 1");
										$SQL -> execute(array(':id' => $delete));
									}
									echo '<div class="g_12"><div class="alert alert-success><strong>Success</strong>: Method has been removed</div></div>';
								}
								if (isset($_POST['apiAdd']))
								{
									$apiAdd = $_POST['api'];
									if (empty($apiAdd))
									{
										echo '<div class="alert alert-danger"><strong>Error</strong>: please fill in all the field that are required!</div>';
									}
									else
									{
										$SQLinsert = $odb -> prepare("INSERT INTO `api` VALUES(NULL, :api)");
										$SQLinsert -> execute(array(':api' => $apiAdd));
										echo '<div class="alert alert-success"><strong>Success</strong>: api has been added!</div>';
									}
								}
								?>
								<?php
								if (isset($_POST['deleteBtnAPI']))
									{
										$deletes = $_POST['deleteCheckAPI'];
										foreach($deletes as $delete)
										{
											$SQL = $odb -> prepare("DELETE FROM `api` WHERE `ID` = :id LIMIT 1");
											$SQL -> execute(array(':id' => $delete));
										}
										echo '<div class="g_12"><div class="alert alert-success><strong>Success</strong>: Server has been removed</div></div>';
									}
							?>
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Add Method</h6>
							<form action="" method="POST" class="form-horizontal">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Display Name</label>
									<input class="form-control" name="friendly" type="text" placeholder="OVH-BYPASS (UDP)"/>
                                    <div id="emailHelp" class="form-text">What this will display as so add (udp or tcp) if you want
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Method Name</label>
									<input class="form-control" name="name" type="text" placeholder="OVH-BYPASS"/>
									<div id="emailHelp" class="form-text">Method put into api/server 
                                    </div>
								</div>
							<h6 class="mb-3">Add API</h6>
							<form action="" method="POST" class="form-horizontal">
							<div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Password</label>
									<input class="form-control" name="api" placeholder="<?php
											$getNames = $odb -> query("SELECT * FROM `admin`");
											while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
												echo $Names['booterurl'];
											}
										?>/send.php?key=[key]&target=[host]&port=[port]&time=[time]&method=[method]" type="text"/>
									<div id="emailHelp" class="form-text">Method put into api/server 
                                    </div>
                        </div>
						<div class="panel-footer">
									<button type="submit" name="methodAdd" class="btn btn-sm btn-success"><i class="fa fa-flash"></i> Add Method</button>
									<button type="submit" name="apiAdd" class="btn btn-sm btn-success"><i class="fa fa-flash"></i> Add Api</button>
								</div>	
							</form>
							</div>
					</div>
					<div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Methods</h6>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Display Name</th>
                                        <th scope="col">Method Name</th>
										<th scope="col">Delete?</th>
                                    </tr>
                                </thead>
                                <tbody>
								<?php
								  $SQLSelect = $odb -> query("SELECT * FROM `methods` ORDER BY `id` ASC");
								  while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
								  {
									$friendlyShow = $show['friendly'];
									$nameShow = $show['name'];
									$rowID = $show['ID'];
									echo '<tr>
									<td>'.$rowID.'</td>
									<td>'.$friendlyShow.'</td>
									<td>'.$nameShow.'</td>
									<td><button type="submit" class="btn btn-sm btn-primary" name="deleteBtn">Delete</button></td>
									</tr>';
								  }
								  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Api's</h6>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">API</th>
                                    </tr>
                                </thead>
								<tbody>
								<?php
									  $SQLSelect = $odb -> query("SELECT * FROM `api` ORDER BY `id` ASC");
									  while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
									  {
										$apiShow = $show['api'];
										$rowID = $show['ID'];
										echo '<tr><td>'.$rowID.'</td><td>'.$apiShow.'</td></tr>';
									  }
								?>
								</tbody>
                            </table>
                        </div>
                    </div>
				</div>
				
	<div class="clearfix"></div>
	
            <!-- Footer Start -->
            <?php
				$getNames = $odb -> query("SELECT * FROM `admin`");
				while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
					$SiteName = $Names['bootername'];
				}
			?>
            
<div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"><?php echo $SiteName ?></a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            Designed By <a href="#">FileGone</a>
                            <br>Distributed By: <a href="#" target="_blank"><?php echo $SiteName ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
			
	<!-- start: JavaScript-->
		    <!-- JavaScript Libraries -->
			<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/chart/chart.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../lib/tempusdominus/js/moment.min.js"></script>
    <script src="../lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../js/main.js"></script>
	<!--[if !IE]>-->
	
</body>
</html>