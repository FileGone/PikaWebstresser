<?php
ob_start();
include '../core/database.php';

if (!($user -> LoggedIn()))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
if (!($user -> isAdmin($odb)))
{
	die('You are not admin');
}
if (!($user -> notBanned($odb)))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Checking...</title>
     <meta charset="UTF-8" />
     <meta http-equiv="refresh" content="3; URL=index.php" />
   </head>
   <body>
     <p>Checking if you are admin. if you are still here leave my site you hacker</p>
   </body>
</html>