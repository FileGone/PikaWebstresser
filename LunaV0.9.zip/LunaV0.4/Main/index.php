<?php
ob_start();
include 'core/header.php';

if (!($user -> LoggedIn()))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
// Check if user is logged in
if (isset($_SESSION['ID'])) {
    $userID = $_SESSION['ID'];

    $SQL = $odb->prepare("SELECT `plans`.`con` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`ID` = :id");
    $SQL->execute(array(':id' => $_SESSION['ID']));
    $user2 = $SQL->fetch(PDO::FETCH_ASSOC);
    try {
        // Fetch user information from the database
        $query = "SELECT * FROM `users` WHERE `ID` = :userID";
        $statement = $odb->prepare($query);
        $statement->bindParam(':userID', $userID);
        $statement->execute();
        $user = $statement->fetch(PDO::FETCH_ASSOC);


        // Check if user information exists
        if ($user) {
            // Populate variables with user information
            $username = $user['username'];
            $email = $user['email'];
            $bootTime = isset($user['mbt']) ? $user['mbt'] : "0";
            $concurrents = isset($user2['con']) ? $user2['con'] : "0";
            $membership = $user['membership'];
            $expiryDate = $user['expire'];
        } else {
            // User information not found
            $username = $user['username'];
            $email = $user['email'];
            $bootTime = "0";
            $concurrents = "0";
            $membership = $user['membership'];
            $expiryDate = $user['expire'];
        }
    } catch (PDOException $e) {
        // Display the SQL error message
        echo "SQL Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Luna - Hub</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">

        <!-- Content Start -->
        <div class="content">


            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-user fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Users:</p>
                                <h6 class="mb-0">
                                    <?php echo $stats->totalUsers($odb); ?>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Attacks:</p>
                                <h6 class="mb-0">
                                    <?php echo $stats->totalBoots($odb); ?>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-area fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Running Attacks:</p>
                                <h6 class="mb-0">
                                    <?php echo $stats->runningBoots($odb); ?>/
                                    <?php echo $maxBootSlots; ?>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-sitemap fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">API's:</p>
                                <h6 class="mb-0">2</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sale & Revenue End -->
            <?php 
					$plansql = $odb -> prepare("SELECT `users`.*,`plans`.`name`, `plans`.`mbt`, `plans`.`con` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id LIMIT 1");
					$plansql -> execute(array(":id" => $_SESSION['ID']));
					$userInfo = $plansql -> fetch(PDO::FETCH_ASSOC);
				?>
            <!-- Sales Chart Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary text-center rounded p-4">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <h6 class="mb-0">Total Attacks</h6>
                                <a href="">Show All</a>
                            </div>
                            <canvas id="worldwide-sales"></canvas>
                        </div>
                    </div>

                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary text-center rounded p-4">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <img class="img-fluid rounded-circle mx-auto mb-4" src="img/user.png"
                                    style="width: 100px; height: 100px;">
                            </div>

                            <h5 class="mb-1">Stats</h5>

                            <p>Username:
                                <?php echo $username; ?>
                            </p>
                            <p>Email:
                                <?php echo $email; ?>
                            </p>
                            <p>Boot Time:
                                <?php echo $userInfo['mbt']; ?>
                            </p>
                            <p>Concurrents:
                                <?php echo $concurrents; ?>
                            </p>
                            <p>Plan:
                                <?php echo  $userInfo['name']; ?>
                            </p>
                            <p>Expiry:
                                <?php echo date('m-d-Y' ,$userInfo['expire']); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sales Chart End -->


            <!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-secondary text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Active Attacks</h6>
                        <a href="">Show All</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">#</th>
                                    <th scope="col">Attacker</th>
                                    <th scope="col">Host</th>
                                    <th scope="col">Timer</th>
                                    <th scope="col">Port</th>
                                    <th scope="col">Method</th>
                                </tr>
                            </thead>
                             <tbody>
                             <?php
									$SQLSelect = $odb -> query("SELECT * FROM `logs` ORDER BY `id` DESC LIMIT 5;");
									while ($show = $SQLSelect -> fetch(PDO::FETCH_ASSOC))
									{
									$ip = $show['ip'];
									$port = $show['port'];
									$time = $show['time'];
									$method = $show['method'];
									$rowID = $show['id'];
                                    $name = $show['user'];
									echo '                                    <tr>
                                    <td><input class="form-check-input" type="checkbox"></td>
                                    <td>'.$rowID.'</td>
                                    <td>'.$name.'</td>
                                    <td>'.$ip.'</td>
                                    <td>'.$time.'</td>
                                    <td>'.$port.'</td>
                                    <td>'.$method.'</td>
                                    <td><a class="btn btn-sm btn-primary" href="">Detail</a></td>
                                </tr>';
										
									//echo date("r", ($show['time'] + $show['date'])) . "<br />";
                                    }
									?>

									<div id='att-<?php echo $rowID; ?>'></div>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Recent Sales End -->
								</tbody>
							 </table>     
						</div>
					   </form>
					</div>
				</div>
			</div><!--/row-->




		</div>
	</div>
	<div class="clearfix"></div>


            <!-- Footer Start -->
            <?php
				$getNames = $odb -> query("SELECT * FROM `admin`");
				while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
					$SiteName = $Names['bootername'];
				}
			?>
            
<div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"><?php echo $SiteName ?></a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            Designed By <a href="#">FileGone</a>
                            <br>Distributed By: <a href="#" target="_blank"><?php echo $SiteName ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->


        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->

    <script src="js/main.js"></script>
</body>

</html>