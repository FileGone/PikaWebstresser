<?php
include("core/database.php");
?>
<?php
				$getNames = $odb -> query("SELECT * FROM `admin`");
				while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
					$SiteName = $Names['bootername'];
				}
			?>
            
<div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"><?php echo $SiteName ?></a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            Designed By <a href="#">FileGone</a>
                            <br>Distributed By: <a href="#" target="_blank">Pika</a>
                        </div>
                    </div>
                </div>
            </div>