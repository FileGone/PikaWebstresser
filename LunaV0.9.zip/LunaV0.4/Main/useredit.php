<?php
$page = "Account Information";
include("core/header.php");

$error_reporting = error_reporting(E_ALL);
ini_set("display_errors", "on");

if (!($user -> LoggedIn()))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
if (!($user -> notBanned($odb)))
{
	header('location: /LunaV0.4/Main/signup.php');
	die();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Luna - Hub</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">

        <!-- Content Start -->
        <div class="content">
			

			<div class="row">
				
				<div class="col-md-6">
				<?php 
				if (isset($_POST['updatePassBtn']))
				{
					$cpassword = $_POST['cpassword'];
					$npassword = $_POST['npassword'];
					$rpassword = $_POST['rpassword'];
					if (!empty($cpassword) && !empty($npassword) && !empty($rpassword))
					{
						if ($npassword == $rpassword)
						{
							$SQLCheckCurrent = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username AND `password` = :password");
							$SQLCheckCurrent -> execute(array(':username' => $_SESSION['username'], ':password' => SHA1($cpassword)));
							$countCurrent = $SQLCheckCurrent -> fetchColumn(0);
							if ($countCurrent == 1)
							{
								$SQLUpdate = $odb -> prepare("UPDATE `users` SET `password` = :password WHERE `username` = :username AND `ID` = :id");
								$SQLUpdate -> execute(array(':password' => SHA1($npassword),':username' => $_SESSION['username'], ':id' => $_SESSION['ID']));
								echo '<div class="g_12"><div class="alert alert-success"><strong>SUCCESS</strong>: Password has been updated</div></div>';
							}
							else
							{
								echo '<div class="g_12"><div class="alert alert-danger"><strong>ERROR</strong>: Current Password is incorrect</div></div>';
							}
						}
						else
						{
							echo '<div class="g_12"><div class="alert alert-danger"><strong>ERROR</strong>: New passwords did not match</div></div>';
						}
					}
					else
					{
						echo '<div class="g_12"><div class="alert alert-danger"><strong>ERROR</strong>: Please fill in all fields</div></div>';
					}
				}
				if (isset($_POST['updateEmailBtn']))
				{
					$cpassword = $_POST['cpassword'];
					$nemail = $_POST['nemail'];
					if (!empty($cpassword) && !empty($nemail))
					{
						if (filter_var($nemail, FILTER_VALIDATE_EMAIL))
						{
							$SQLCheckCurrent = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username AND `password` = :password");
							$SQLCheckCurrent -> execute(array(':username' => $_SESSION['username'], ':password' => SHA1($cpassword)));
							$countCurrent = $SQLCheckCurrent -> fetchColumn(0);
							if ($countCurrent == 1)
							{
								$SQLUpdate = $odb -> prepare("UPDATE `users` SET `email` = :email WHERE `username` = :username AND `ID` = :id");
								$SQLUpdate -> execute(array(':email' => $nemail,':username' => $_SESSION['username'], ':id' => $_SESSION['ID']));
								echo '<div class="g_12"><div class="alert alert-success"><strong>SUCCESS</strong>: Email has been updated</div></div>';
							}
							else
							{
								echo '<div class="g_12"><div class="alert alert-danger">ERROR: Current password is incorrect</div></div>';
							}
						}
						else
						{
							echo '<div class="g_12"><div class="alert alert-danger"><strong>ERROR</strong>: Invalid email</div></div>';
						}
					}
					else
					{
						echo '<div class="g_12"><div class="alert alert-danger"><strong>ERROR</strong>: Please fill in all fields</div></div>';
					}
				}
				?>
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                        <h6 class="mb-4">Send Attack</h6>
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="Email-tab" data-bs-toggle="pill"
                                        data-bs-target="#Email" type="button" role="tab" aria-controls="Email"
                                        aria-selected="true">Email</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="password-tab" data-bs-toggle="pill"
                                        data-bs-target="#password" type="button" role="tab"
                                        aria-controls="password" aria-selected="false">Password</button>
                                </li>
							</ul>
							<div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                    Sit sanctus et stet dolor kasd kasd takimata. Dolor stet dolores nonumy et dolor et eos lorem et, diam ipsum nonumy elitr sanctus dolores voluptua sit dolor, at et et amet nonumy elitr ea et ipsum. Elitr lorem et dolore invidunt eirmod voluptua lorem sed. Sed eirmod sadipscing eos tempor.
                                </div>
                                <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                                    Invidunt rebum voluptua lorem eirmod dolore. Amet no sed sanctus lorem ea. Nonumy sit stet sit magna. Rebum rebum ipsum clita erat consetetur, sit dolor sit clita et amet. Est et clita dolore takimata, sea dolores tempor erat consetetur lorem. Consetetur sea sadipscing dolor et dolores et stet, tempor elitr.
                                </div>
                                <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                    Et diam et est sed vero ipsum voluptua dolor et, sit eos justo ipsum no ipsum amet sed aliquyam dolore, ut ipsum sanctus et consetetur. Sit ea sit clita lorem ea gubergren. Et dolore vero sanctus voluptua ipsum sadipscing amet at. Et sed dolore voluptua dolor eos tempor, erat amet.
                                </div>
                            </div>
						</div>
						<div class="panel-body">
							
							<div id="myTabContent" class="tab-content">
								<div class="tab-pane" id="info">
							<div class="panel-body">
							<form action="" method="post" class="form-horizontal ">
				                <div class="form-group">
				                    <label class="col-md-3 control-label" for="hf-email">Current Password</label>
				                    <div class="col-md-9">
				                        <input type="password" id="hf-password" name="cpassword" class="form-control" placeholder="Current Password">
				                        <span class="help-block">Please enter your password</span>
				                    </div>
				                </div>
								 <div class="form-group">
				                    <label class="col-md-3 control-label" for="hf-email">New Password</label>
				                    <div class="col-md-9">
				                        <input type="password" id="hf-password" name="npassword" class="form-control" placeholder="New Password">
				                        <span class="help-block">Please enter your password</span>
				                    </div>
				                </div>
				                <div class="form-group">
				                    <label class="col-md-3 control-label" for="hf-password">Repeat Password</label>
				                    <div class="col-md-9">
				                        <input type="password" id="hf-password" name="rpassword" class="form-control" placeholder="Repeat Password">
				                        <span class="help-block">Please enter your password</span>
				                    </div>
				                </div>
						</div>
						<div class="panel-footer">
		                    <button type="submit" name="updatePassBtn" class="btn btn-sm btn-success"><i class="fa fa-lock"></i> Submit</button>
							</form>
		                </div>

								</div>
								<div class="tab-pane" id="custom">
									<div class="panel-body">
							<form action="" method="POST" class="form-horizontal ">
				                <div class="form-group">
				                    <label class="col-md-3 control-label" for="hf-email">New Email</label>
				                    <div class="col-md-9">
				                        <input type="email" id="hf-email" name="email" class="form-control" placeholder="Enter Email..">
				                        <span class="help-block">Please enter your email</span>
				                    </div>
				                </div>
				                <div class="form-group">
				                    <label class="col-md-3 control-label" for="hf-password">Current Password</label>
				                    <div class="col-md-9">
				                        <input type="password" id="hf-password" name="cpassword" class="form-control" placeholder="Enter Password..">
				                        <span class="help-block">Please enter your password</span>
				                    </div>
				                </div>
						</div>
						<div class="panel-footer">
		                    <button type="submit" name="updateEmailBtn" class="btn btn-sm btn-success"><i class="fa fa-envelope"></i> Update</button>
		                </div>
							</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
				<?php 
					$plansql = $odb -> prepare("SELECT `users`.*,`plans`.`name`, `plans`.`mbt`, `plans`.`con` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id LIMIT 1");
					$plansql -> execute(array(":id" => $_SESSION['ID']));
					$userInfo = $plansql -> fetch(PDO::FETCH_ASSOC);
				?>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h2><i class="fa fa-align-justify"></i><span class="break"></span>Memebership Information</h2>
							<div class="panel-actions">
								<a href="table.html#" class="btn-setting"><i class="fa fa-wrench"></i></a>
								<a href="table.html#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
								<a href="table.html#" class="btn-close"><i class="fa fa-times"></i></a>
							</div>
						</div>
						<div class="panel-body">
							<table class="table table-bordered">
									<tr>
									<td>Username:</td>
									<td><?php echo $userInfo['username']; ?></td>
								</tr>
								<tr>
									<td>Email:</td>
									<td><?php echo $userInfo['email']; ?></td>
								</tr>
								<tr>
									<td>Membership:</td>
									<td><?php echo $userInfo['name']; ?></td>
								</tr>
								<tr>
									<td>Max Boot:</td>
									<td><?php echo $userInfo['mbt']; ?></td>
								</tr>
								<tr>
									<td>Concurrents:</td>
									<td><?php echo $userInfo['con']; ?></td>
								</tr>
								<tr>
									<td>Expire:</td>
									<td><?php echo date('m-d-Y' ,$userInfo['expire']); ?></td>
								</tr>                                   
								  </tbody>
							 </table>  
						</div>
					</div>
				</div>
				</div><!--/col-->	
		</div>
	</div>
	<div class="clearfix"></div>
            <!-- Footer Start -->
            <?php
				$getNames = $odb -> query("SELECT * FROM `admin`");
				while($Names = $getNames -> fetch(PDO::FETCH_ASSOC)) {
					$SiteName = $Names['bootername'];
				}
			?>
            
<div class="container-fluid pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"><?php echo $SiteName ?></a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            Designed By <a href="#">FileGone</a>
                            <br>Distributed By: <a href="#" target="_blank"><?php echo $SiteName ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
	<?php include "footer.php"; ?>
		
	<!-- start: JavaScript-->
	<!--[if !IE]>-->

			<script src="assets/js/jquery-2.1.0.min.js"></script>

	<!--<![endif]-->

	<!--[if IE]>
	
		<script src="assets/js/jquery-1.11.0.min.js"></script>
	
	<![endif]-->

	<!--[if !IE]>-->

		<script type="text/javascript">
			window.jQuery || document.write("<script src='assets/js/jquery-2.1.0.min.js'>"+"<"+"/script>");
		</script>

	<!--<![endif]-->

	<!--[if IE]>
	
		<script type="text/javascript">
	 	window.jQuery || document.write("<script src='assets/js/jquery-1.11.0.min.js'>"+"<"+"/script>");
		</script>
		
	<![endif]-->
	<script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>	
	
	
	<!-- page scripts -->
	<script src="assets/js/jquery-ui.min.js"></script>
	<script src="assets/js/jquery.ui.touch-punch.min.js"></script>
	<script src="assets/js/jquery.sparkline.min.js"></script>
	<script src="assets/js/fullcalendar.min.js"></script>
	<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="assets/js/excanvas.min.js"></script><![endif]-->
	<script src="assets/js/jquery.flot.min.js"></script>
	<script src="assets/js/jquery.flot.pie.min.js"></script>
	<script src="assets/js/jquery.flot.stack.min.js"></script>
	<script src="assets/js/jquery.flot.resize.min.js"></script>
	<script src="assets/js/jquery.flot.time.min.js"></script>
	<script src="assets/js/jquery.flot.spline.min.js"></script>
	<script src="assets/js/jquery.autosize.min.js"></script>
	<script src="assets/js/jquery.placeholder.min.js"></script>
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/daterangepicker.min.js"></script>
	<script src="assets/js/jquery.easy-pie-chart.min.js"></script>
	<script src="assets/js/jquery.dataTables.min.js"></script>
	<script src="assets/js/dataTables.bootstrap.min.js"></script>
	<script src="assets/js/raphael.min.js"></script>
	<script src="assets/js/morris.min.js"></script>
	<script src="assets/js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="assets/js/uncompressed/jquery-jvectormap-world-mill-en.js"></script>
	<script src="assets/js/uncompressed/gdp-data.js"></script>
	<script src="assets/js/gauge.min.js"></script>
	
	<!-- theme scripts -->
	<script src="assets/js/custom.min.js"></script>
	<script src="assets/js/core.min.js"></script>
	
	<!-- inline scripts related to this page -->
	<script src="assets/js/pages/index.js"></script>
	
	<!-- end: JavaScript-->
	
</body>
</html>